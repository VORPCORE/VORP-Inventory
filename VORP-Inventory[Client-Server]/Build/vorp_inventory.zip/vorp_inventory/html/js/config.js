var Config = new Object();
Config.closeKeys = [113, 27];